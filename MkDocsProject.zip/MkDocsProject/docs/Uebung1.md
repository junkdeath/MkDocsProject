# Übung Normalisierung und Relationenmodell

Lorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquid ex ea commodi consequat. Quis aute iure reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint obcaecat cupiditat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

## Das Material Thema

??? tip "Ein Tipp für Code-Beispiele"
    Schlüsselwort `tip`
    Hier folgt der Inhalt des Kastens.
    Eingerückt per Tab.
    ```
    Code im Kasten: whoami
    ```

!!! danger "Eine Gefahr"
    Schlüsselwort `danger`
    Hier muss man aufpassen!

Die Liste der Erweiterungen des Material-Themas

1. abstract
2. info 
3. tip
4. success
5. question
6. warning
7. failure
8. danger
9. bug
10. quote

## Nützliche Links
Zum 

* [Online Tutorial](https://www.markdownguide.org/getting-started/)
* [Material Thema](https://squidfunk.github.io/mkdocs-material/getting-started/)
* c't-Artikel[^1] ["Doku Freuden"](pdf/ct.20.18.160-162.pdf)

[^1]: c't 18/2020, Seite 160ff. Heise Medien GmbH & Co. KG, Hannover





